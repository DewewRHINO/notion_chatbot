# AWS Pen testing Lab

Author : Jacob Jayme

# Introduction

**AWSGoat: A Damn Vulnerable AWS Infrastructure.** 

AWSGoat is a vulnerable by design infrastructure on AWS featuring the latest released OWASP Top 10 web application security risks (2021) and other misconfiguration based on services such as IAM, S3, API Gateway, Lambda, EC2, and ECS. AWSGoat mimics real-world infrastructure but with added vulnerabilities. It features multiple escalation paths and is focused on a black-box approach.

AWSGoat uses IaC (Terraform) to deploy the vulnerable cloud infrastructure on the user's AWS account. This gives the user complete control over code, infrastructure, and environment. Using AWSGoat, the user can learn/practice:

- Cloud Pentesting/Red-teaming
- Auditing IaC
- Secure Coding
- Detection and mitigation

# Module 1

---

Server-less blog application using Lambda, S3 Buckets, API Gateway, and DynamoDB. 

## Reflected XSS on main site

First thing you will notice is the website. 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled.png)

We can try putting in XSS attacks where we inject malicious scripts into the website. If we look at the html code in the website we can try to find vulnerable code that might be related to it. First we can try `<script>alert('1')</script>` . 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%201.png)

As you can see it doesn’t work. We can keep trying out different attacks until it works. A specific tag called `img` works. Full command I used was `<img src='a' onerror=alert('f')>` .

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%202.png)

This shows that this web application is vulnerable to XSS injection attacks. 

## SQL Injection on the Sign-in Page

If we click the user profile on the left-hand page we can try to sign in. Here I created a user and went to see what I could do with it. 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%203.png)

After creating the account I see this page: 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%204.png)

Notice how on the left hand side there are users, click on that and see what happens: 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%205.png)

I see a few users are on there and some are banned. Thinking through this I think I can put this through burp and see if there are any vectors of attack because, all this information has to come from a database. 

Running burp on the website and seeing what I can find leads me to this: 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%206.png)

As you can see in the POST request to get users for the website, there is an `"authLevel"` that is provided. This can be the reason why some of the information of the users is grayed out and maybe having a lower authLevel might reveal more information about it. I send it to repeater. 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%207.png)

Then I change the `"authlevel"` to 0 and send the post request and I can see the following information. 

![Untitled](AWS%20Pen%20testing%20Lab%20791710e0f7c64c4690e460d89a8856bb/Untitled%208.png)

As you can see none of these have passwords. 

**********Note:********** Oops this isn’t really sql injection looking at the write ups they used:

```
"authlevel":"hello' or '1'='1
```

Instead of what I put which was just 0. 

# Resources

---

[https://github.com/ine-labs/AWSGoat](https://github.com/ine-labs/AWSGoat)

[AWS Marketplace: Check Point Security Management](https://aws.amazon.com/marketplace/pp/prodview-opyyrovueimx2#pdp-usage)

# Vulnerabilities

---

The project is scheduled to encompass all significant vulnerabilities including the OWASP TOP 10 2021, and popular cloud misconfiguration. Currently, the project  contains the following 
vulnerabilities/misconfiguration.

- XSS
- SQL Injection
- Insecure Direct Object Reference
- Server Side Request Forgery on Lambda Environment
- Sensitive Data Exposure and Password Reset
- S3 Misconfiguration
- IAM Privilege Escalations
- ECS Container Breakout