# Home Lab Documentation

# Resources

---

[Jacob's Home Lab Inventory](https://docs.google.com/spreadsheets/d/1eoflDh3oGRvOsCpF8ddNMcdc-3ciDU7oSC3gS9HM7o0/edit?usp=sharing)

### Windows Guides/Articles

---

[Windows_Checklist.pdf](Home%20Lab%20Documentation%20f6b10d660ae54622a3d08c2a07393dc9/Windows_Checklist.pdf)

[RootDSE](https://rootdse.org/)

### Linux Guides/Articles

---

[Linux_Checklist.pdf](Home%20Lab%20Documentation%20f6b10d660ae54622a3d08c2a07393dc9/Linux_Checklist.pdf)

[Securing a Linux Server](https://sourque.com/blog/securing-a-linux-server/)

[Hunting for Persistence in Linux (Part 1): Auditd, Sysmon, Osquery (and Webshells)](https://pberba.github.io/security/2021/11/22/linux-threat-hunting-for-persistence-sysmon-auditd-webshell/)

# Documentation Board

---

Domain: pokemoncenter.com

[Untitled Database](Home%20Lab%20Documentation%20f6b10d660ae54622a3d08c2a07393dc9/Untitled%20Database%207b7c5b8400a44227bc101b310fe4801c.csv)