# Investing Notes

# Research topics

1.) Business Cycles 

2.). Security vs Commodity 

3.) The printing out of trillions of dollars by our government causing inflation and devaluing the U.S dollar 

4.) No matter how MUCH money we make it wont bring true happiness so why not invest a reasonable amount for a better tmrw