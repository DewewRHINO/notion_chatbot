# Lunch w/ Dad

Amount: 25
Category: Food
Date: November 8, 2022