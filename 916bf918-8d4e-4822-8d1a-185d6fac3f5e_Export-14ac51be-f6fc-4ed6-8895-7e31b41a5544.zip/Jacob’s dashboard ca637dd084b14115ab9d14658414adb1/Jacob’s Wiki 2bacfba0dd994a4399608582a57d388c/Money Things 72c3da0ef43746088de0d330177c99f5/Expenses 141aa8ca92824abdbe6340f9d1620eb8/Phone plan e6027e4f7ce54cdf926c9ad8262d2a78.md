# Phone plan

Amount: 80
Category: Home
Date: November 5, 2022