# Groceries

Amount: 55
Category: Home
Date: November 16, 2022