# Trade Options Notes

- **Options:** What you are buying is the right to transact on a stock at a specific price before a certain date.
- ********Calls Option:******** Gives the buyer of the call option the right to BUY the underlying stock at the strike price, at any time on or before the expiry date.
    - ****************Example****************
        
        `AAPL Aug 20 2021 145 Call`
        
        → Underlying is AAPL 
        
        → Strike Price is $145 
        
        → Expiry Date is Aug 20, 2021
        
        → Premium is $5
        
    - **Buying vs. Selling A Call Option**
        - Buying a call → Bullish: Benefit if the market goes up.
        - Selling a call → Bearish: Benefit if the market goes down

![Untitled](Trade%20Options%20Notes%20b81e527d5efd4227b77bbd2e3959a6fe/Untitled.png)

- ****************************Puts Options:**************************** Gives the buyer of the put option the right to SELL the underlying stock at the strike price, any time on or before the expiry date.
    - Example
        
        `AAPL Aug 20 2021 145 Call`
        
        → Underlying is AAPL 
        
        → Strike Price is $145 
        
        → Expiry Date is Aug 20, 2021
        
        → Premium is $5
        

## Extra Notes/Terms

- **************Calls example:************** Where you buy the right to buy a stock at a specific price. You believe that the stock will go up at a certain date.
    - For example if you wanted to buy Apple at $145 and you think it will go up at $200, your profit would be $55. You are essentially buying the right to buy Apple at $145 if it reaches $200. So when you make that call and the price is around $200 you can buy each stock for $145. $145 at this point would be your ****************************strike price.**************************** Then just sell it right around for $200. Instead of buying it directly it’s more round about. If apple goes down, it will be below $145, so you basically don’t sell at this point. This call option would then be worthless.
    - Downside is always fixed, just the fee you paid to go into the contract.
    - Compared to stocks, options have an asymmetrical payoff profile. Limited downside with unlimited upside. Options are not free and have an expatriation date.