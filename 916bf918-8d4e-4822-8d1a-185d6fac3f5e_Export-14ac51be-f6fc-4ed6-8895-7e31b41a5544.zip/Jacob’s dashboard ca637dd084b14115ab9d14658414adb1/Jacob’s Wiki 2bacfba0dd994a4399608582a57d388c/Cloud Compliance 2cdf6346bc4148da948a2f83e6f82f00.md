# Cloud Compliance

Author : Jacob Jayme

# Introduction

Cloud environments are very dynamic and rapidly changing making it difficult to enforce security at scale. Cloud governance is critical to maintain compliance with regulatory requirements and security policies as the evolve. Need to learn also how to integrate security into their CI/CD pipeline and software development lifecycle. 

**********************************************************************************Taking cloud security to the next maturity level begins with continuous security governance and compliance, and a prevention-focused state of mind.********************************************************************************** 

## Understanding your Security Posture on AWS

Shared Responsibility model is very important, in that AWS is only responsible for security “of” the cloud and you are responsible for “in” the cloud. 

![Untitled](Cloud%20Compliance%202cdf6346bc4148da948a2f83e6f82f00/Untitled.png)

# 6 Steps to Compliance Automation

1. Gain Visibility 
2. Select Compliance Framework and Scope
3. Evaluate Initial Results and Plan
4. Monitor Your Continuous Compliance Program
5. Automate Remediation
6. Report and Auditing

## Step 1: Gain Visibility

- Cloud Assets Configuration
- Public Exposure Levels
- Network Topology
- Security Groups
- Traffic and user activity

## Step 2: Select Compliance Framework and Scope

1. Select Relevant Compliance framework
2. Get a clear understanding of your compliance scope

## Step 3: Evaluate Initial Results and Plan

1. Initial assessments
2. Applying Exclusions
3. Adding customization

## Step 4: Monitor your continuous compliance program

1. Define Frequency 
2. Identify Owners 
3. Integrate with other internal processes and supporting tools

## Step 5: Automate Remediation

Automated compliance. 

## Step 6: Reporting and Auditing

# Compliance Frameworks

## SOC 2

SOC 2 audits look at the “how” behind a security control like the way a company does user review will be different from other companies. Usually custom to each company. 

- Based on security, availability, processing integrity, confidentiality, and privacy.
- How to manage customer data
- Type 1: Describes the organization’s systems and whether the system design complies with the relevant trust principles
- Type 2: details the operational efficiency of these systems.

## PCI DSS

The payment Card Industry Data Security Standard (PCI DSS) set of requirements intended to ensure that all companies that process, store, or transmit credit card information maintain a secure environment. 

## FedRamp/NIST

Fedramp is important because business wide means that a business’s cloud security is deemed secure enough to host and or handle federal information. Pretty big contract wise. 

# **Check Point Security Management**

[AWS Marketplace: Check Point Security Management](https://aws.amazon.com/marketplace/pp/prodview-opyyrovueimx2#pdp-usage)