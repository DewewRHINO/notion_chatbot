# Food Plan

## Options

[https://youtu.be/ydbMAFaA6Uw](https://youtu.be/ydbMAFaA6Uw)

[https://youtu.be/4ZdaEdo73cs](https://youtu.be/4ZdaEdo73cs)

[https://youtu.be/XXL0ptVsmiE](https://youtu.be/XXL0ptVsmiE)

[https://youtu.be/dLairfd8bZU](https://youtu.be/dLairfd8bZU)

[https://youtu.be/Acs7ZnIdo4o](https://youtu.be/Acs7ZnIdo4o)

[https://youtu.be/1Dd7GNm68hI](https://youtu.be/1Dd7GNm68hI)

[https://youtu.be/UX0fcKTEFC4](https://youtu.be/UX0fcKTEFC4)

[https://youtu.be/oxXNklNgmbM](https://youtu.be/oxXNklNgmbM)

[https://youtu.be/qtUZoKyQFb4](https://youtu.be/qtUZoKyQFb4)

[https://youtu.be/gjhOPHoRJBs](https://youtu.be/gjhOPHoRJBs)

### Breakfast

1. SAUSAGE AND EGG BREAKFAST QUESADILLAS - 
    - 8 oz. country sausage ($1.45)
    - 6 large eggs ($1.40)
    - 1/4 tsp salt ($0.02)
    - 1/4 tsp pepper ($0.02)
    - 6 oz. cheddar ($1.27)
    - 6 medium flour tortillas ($0.86)

[Sausage and Egg Breakfast Quesadillas](https://www.budgetbytes.com/sausage-and-egg-breakfast-quesadillas/)

1. Frittata: 
    1. 1 dozen eggs ($4)
    2. 1/2 (120ml) cup milk (($1)
    3. Cooked vegetables of choice (about 1 cup total) ($4)
    4. 1 cup grated cheese(120g)   (3/4 inside the rest of the 1/4 on top (2.75)
    5. 2 tablespoons (24g) butter $.50)
    6. Salt and pepper to taste
2. Breakfast Sandwich 
    1. Bread 
    2. Spicy Mayoli 
    3. 4 slices gouda cheese
    4. 4 slices chedar cheese
    5. 2 large tomatoes (gonna brulee)
    6. 12 good slices mortadella, seared
    7. 4 large eggs, fried
    8. fresh basil leaves
    9. Spicy Mayoli

## Lunch

1. Not English Beans on Toast: 
    1. 12 oz chorizo (3 dollars)
    2. 3/4 teaspoon (2g) red pepper flakes .10 cents
    3. 4 cloves garlic toasted .20 cents
    4. 1/2 cup (120ml) water
    5. 2 cans white navy beans (2.50)
    6. 3 cups 75g baby spinach 2.00
    7. 17.6 oz (500g) Container crushed tomatoes 2.75
    8. Bread (4.00)
2. Bowtie pasta and broccoli 
    - 12 oz. pasta ($1.00)
    - 1 lb. frozen broccoli florets ($1.69)
    - 3 Tbsp butter ($0.30)
    - 3 Tbsp [grated Parmesan](https://amzn.to/3H30hgm) ($0.31)
    - Salt to taste ($0.05)
    - Freshly cracked pepper to taste ($0.10)
    - 1 pinch crushed red pepper (optional) ($0.05)

## Dinner

1. Pasta Aglio E Olio
    1. 1lb spaghetti ($1.50)
    2. Salt to taste
    3. 1/4 cup plus 2 tablespoons olive oil ($3.00)
    4. 4 cloves garlic (.20 cents)
    5. 1/2 teaspoon (1g)crushed red pepper flakes (.10 cents)
    6. 1/4 cup (10g)finely chopped parsley ($1.00)