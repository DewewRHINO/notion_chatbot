# CS2640 Final Study Guide

The final will consist of a paper exam with 10 questions, max of 4 questions in each of the following areas:

1) Procedure Call Vocabulary – Know the different vocabulary we discussed in class with regards to creating and running procedures in MIPS assembly programming. e.g. caller, return address, stack pointer, saved register section, etc...

2) Array Addressing – Understand how to determine the correct resulting value given a base address and offset and determine the offset from a base address given a particular value when dealing with an array initialized in the data segment as well as how to use register values as pointers into an array.

3) Implementing Control Structures – Know how to write if-then or if-then-else equivalent statements in assembly as well as loops.

4) Procedure Calls – Know how call a procedure and return from it, how to push/pop a stack frame, how to pass and retrieve arguments using registers and the stack, and how to save/restore the return address on the stack.

5) Records/Structs – Know how to create objects using struct like structures, and how to access the data of said objects.

6) Linked Lists – Know how to create or traverse linked lists.

[2640 Cheat sheet](CS2640%20Final%20Study%20Guide%200ee0281eeaf3414e9d3ddf7588f8e464/2640%20Cheat%20sheet%2066182ba58f654a5f87afec1c1752c7ec.md)

Describe the actions necessary for the epilog of a subroutine.

```
The actions necessary for the epilog of a subroutine are:
-place any return values into our v registers
- pop our local variables off the stack, if we are using frame-based linkage.
-pop and restore any s registers we used in our subroutine.
-pop and restore the caller’s $fp value, if we are using frame-based linkage.
-pop and restore our $ra value if we pushed it onto the stack in our prolog.
-use jr $ra to pass control back to the caller.
```

Describe the purpose of the frame pointer

```
The purpose of the frame pointer is to give us a static reference point from where we can access our local variables we placed on the stack.
```

Describe what is meant by regaining control from a callee

```
This means that the callee has used the jr $ra instruction to pass control of the code that is being executed back to the caller, and the caller now will pop and restore any t register values that they wanted to save and pushed onto the stack prior to the subroutine call.
```

When we are discussing a calling convention what do we mean and what is needed to be agreed upon? 

```
A calling convention means we are discussing an agreement about how subroutines are to be called, how control is returned to the caller, and we need to agree upon our register uses and who is responsible for saving data from which registers.
By convention $t registers are to be saved by the caller if they want to keep that data between subroutine calls, $s registers are to be saved by the callee if they want to use these registers when called, $a registers are for arguments, and $v registers are for return values.
```

Given the psuedo code write the assembly: 

```
int i=10;              // initializes an integer i to 10
for(int j = 0; j<5; j++)   // for loop that runs 5 times
{
    if (j>2)               // if the loop counter is greater than 2
        i+=3;              // increments i by 3
    else
        i+=1;              // else, increments i by 1
    print i;               // prints the value of i
}
```

```
.data               // Start of the data segment
i: .word 10         // Declare a word-size piece of data with label 'i' and initial value 10
nl: .asciiz "\n"    // Declare a null-terminated string 'nl' that just contains a newline character

.text               // Start of the text (code) segment
main:               // The main entry point of the program

lw $t1, i           // Load the word at memory address 'i' into register $t1
li $t2, 0           // Load the immediate value 0 into register $t2

loop:               // This is the start of the loop
sltiu $t0, $t2, 5   // Set $t0 to 1 if $t2 < 5 (unsigned comparison), else 0
beq $t0, $0, done   // Branch to 'done' if $t0 == 0 (i.e., if $t2 >= 5)

sltiu $t0, $t2, 3   // Set $t0 to 1 if $t2 < 3 (unsigned comparison), else 0
beq $t0, $0, else   // Branch to 'else' if $t0 == 0 (i.e., if $t2 >= 3)

addiu $t1, $t1, 1   // Add 1 to $t1 and store the result in $t1
j print             // Jump to 'print'

else:               // This is where the program goes if $t2 >= 3
addiu $t1, $t1, 3   // Add 3 to $t1 and store the result in $t1

print:              // This is where the program goes to print the value of i
or $a0, $t1, $0     // Copies the contents of $t1 to $a0 (this is how you pass arguments to a syscall)
li $v0, 1           // Load the immediate value 1 into $v0 (1 is the syscall number for print_int)
syscall             // Perform the syscall

la $a0, nl          // Load the address of 'nl' into $a0 (this is how you pass arguments to a syscall)
li $v0, 4           // Load the immediate value 4 into $v0 (4 is the syscall number for print_string)
syscall             // Perform the syscall

addiu $t2, $t2, 1   // Increment the loop counter
j loop              // Jump back to the start of the loop

done:               // This is where the program goes when it's done looping
li $v0, 10          // Load the immediate value 10 into $v0 (10 is the syscall number for exit)
syscall             // Perform the syscall
```

```
int n = read();      // Reads an integer n from the user
if ( n%2 == 0 )      // If n modulo 2 equals 0
    print “The number is even!”;  // Prints "The number is even!"
else
    print “The number is odd!”;   // Otherwise, prints "The number is odd!"
```

```
.data
even: .asciiz "The number is even!\n"  // Defines a string for "The number is even!"
odd: .asciiz "The number is odd!\n"    // Defines a string for "The number is odd!"

.text
main:
li $v0, 5      // syscall number 5 is for reading an integer
syscall        // perform the system call, which places the result in $v0
or $t1, $v0, $0  // copies the contents of $v0 to $t1

li $t2, 2      // load immediate value 2 into $t2
div $t1, $t2   // divide the contents of $t1 by $t2. The quotient is stored in LO, and the remainder in HI

mfhi $t3       // move the value from HI (the remainder of the division) to $t3

sltiu $t0, $t3, 1  // set $t0 to 1 if $t3 < 1 (unsigned comparison), else 0
beq $t0, $0, podd  // if $t0 equals 0 (i.e., if $t3 >= 1), branch to "podd"

la $a0, even   // load the address of "even" into $a0 (this is how you pass a string to syscall)
li $v0, 4      // syscall number 4 is for printing a string
syscall        // perform the syscall

j done         // jump to "done"

podd:          // this is where the program goes if the number was odd
la $a0, odd    // load the address of "odd" into $a0
li $v0, 4      // syscall number 4 is for printing a string
syscall        // perform the syscall

done:          // this is where the program goes when it's done
li $v0, 10     // syscall number 10 is for exit
syscall        // perform the syscall
```

Creating an array with the numbers 12, 23, 45, 12, -5, 72:

```
li $a0, 24  # Request memory size for 6 integers (6 * 4 bytes = 24 bytes)
li $v0, 9   # syscall number 9 is for requesting memory
syscall     # perform the syscall, the address of the allocated memory is in $v0
or $t0, $v0, $0  # copy the memory address to $t0

# Now, load the values into registers
li $t1, 12
li $t2, 23
li $t3, 45
li $t4, 12
li $t5, -5
li $t6, 72

# And store them in the allocated memory
sw $t1, 0($t0)
sw $t2, 4($t0)
sw $t3, 8($t0)
sw $t4, 12($t0)
sw $t5, 16($t0)
sw $t6, 20($t0)
```

Creating an array with the string "Hello Virtual World!":

1. `li $a0, 20`: This sets the register `$a0` to 20, which is the size of the memory block to be allocated (20 bytes).
2. `li $v0, 9`: This sets the register `$v0` to 9, which is the system call code for allocating a memory block.
3. `syscall`: This initiates the system call.
4. `or $t0, $v0, $0`: This copies the address of the newly allocated memory block from `$v0` to `$t0`.

```
data: "Hello Virtual World!"
li $a0, 20
li $v0, 9
syscall
or $t0, $v0, $0
li $t1, 72 #H
li $t2, 101 #e
li $t3, 108 #l
li $t4, 111 #o
li $t5, 32 #space
sb $t1, 0($t0)
sb $t2, 1($t0)
sb $t3, 2($t0)
sb $t3, 3($t0)
sb $t4, 4($t0)
sb $t5, 5($t0)
li $t1, 86 #V
li $t2, 105 #i
li $t3, 114 #r
li $t4, 116 #t
li $t5, 117 #u
li $t6, 97 #a
li $t7, 108 #l
li $t8, 32 #space
sb $t1, 6($t0)
sb $t2, 7($t0)
sb $t3, 8($t0)
sb $t4, 9($t0)
sb $t5, 10($t0)
sb $t6, 11($t0)
sb $t7, 12($t0)
sb $t8, 13($t0)
li $t1, 87 #W
li $t2, 111 #o
li $t3, 114 #r
li $t4, 108 #l
li $t5, 100 #d
li $t6, 33 #!
sb $t1, 14($t0)
sb $t2, 15($t0)
sb $t3, 16($t0)
sb $t4, 17($t0)
sb $t5, 18($t0)
sb $t6, 19($t0)
```

Creating a static linked list with the following :

32, 54, -27, 7

```
.data
elmnt1: .word 32
.word elmnt2
elmnt2: .word 54
.word elmnt3
elmnt3: .word -27
.word elmnt4
elmnt4: .word 7
.word 0
first: .word elmnt1
```

Mystery program: 

```
int mystery( int arg )
{
int n,m;
n = arg2 + 7;
m = n * 3;
return m;
}
```

```
# Prologue
sw $ra, 0($sp)   # Save the return address
addiu $sp, $sp, -4  # Decrement the stack pointer
sw $fp, 0($sp)   # Save the old frame pointer
addiu $sp, $sp, -4  # Decrement the stack pointer
addiu $fp, $sp, 8  # Set the new frame pointer

# Body
or $t0, $a0, $0     # Copy the argument to $t0
mult $t0, $t0        # Multiply the argument by itself
mflo $t0             # Store the result of the multiplication in $t0
addiu $t0, $t0, 7    # Add 7 to the result
sw $t0, 0($fp)       # Store the result in the memory location pointed by $fp
lw $t0, 0($fp)       # Load the value from the memory location pointed by $fp to $t0
li $t1, 3            # Load the immediate value 3 to $t1
mult $t0, $t1        # Multiply $t0 by 3
mflo $t0             # Store the result of the multiplication in $t0
sw $t0, 4($fp)       # Store the result in the memory location pointed by $fp + 4

# Epilogue
lw $v0, 4($fp)       # Load the result to $v0 (the return register)
addu $sp, $fp, 8     # Adjust the stack pointer to its original position
lw $fp, ($sp)        # Restore the old frame pointer
addu $sp, $sp, 4     # Adjust the stack pointer to its original position
lw $ra, ($sp)        # Restore the return address
addu $sp, $sp, 4     # Adjust the stack pointer to its original position

# Return from function
jr $ra  # Jump to return address
```