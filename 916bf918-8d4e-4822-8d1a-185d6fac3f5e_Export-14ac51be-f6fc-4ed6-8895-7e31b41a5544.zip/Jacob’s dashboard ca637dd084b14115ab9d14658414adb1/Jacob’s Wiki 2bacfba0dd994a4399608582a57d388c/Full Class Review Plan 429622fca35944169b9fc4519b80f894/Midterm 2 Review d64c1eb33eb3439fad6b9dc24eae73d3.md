# Midterm 2 Review

# Dictionary ADT

- Array Based
- Singly Linked List

# Implementations

- Array Based
- Linked List
    - Think of nodes
        - Advantages:
            - Uses memory only as needed
            - when entry is removed, unneeded memory is returned to the system
            - Avoids moving data when adding or removing entries

```
An array-based dictionary and a linked list are both data structures used for storing collections of elements, but they differ in their implementation and performance characteristics.

In an array-based dictionary, the elements are stored in a contiguous block of memory, and each element is accessed using an index. This allows for constant-time access to any element in the array, as long as its index is known. Insertions and deletions can be inefficient, especially if the array needs to be resized to accommodate new elements.

In contrast, a linked list is made up of nodes that store the elements and pointers to the next (and possibly previous) node in the list. Each element in the list can be accessed by traversing the list from the beginning until the desired element is reached. This can be slower than accessing elements in an array-based dictionary, especially for large lists, but it allows for efficient insertions and deletions, since only the pointers to adjacent nodes need to be updated.

In summary, an array-based dictionary is more efficient for random access of elements, while a linked list is more efficient for insertions and deletions. The choice of data structure depends on the specific use case and the relative importance of access time versus insertion and deletion time.
```

# Hashing

A technique that determines an index into a table using only an entry’s search key. 

```
private int getHashIndex(K key)
{
int hashIndex = key.hashCode() % hashTable.length;
if (hashIndex < 0)
hashIndex = hashIndex + hashTable.length;
return hashIndex;
} // end getHashIndex
```

Hash function:

- Takes a search key and produces the integer index of an element in the hash table
- Search key is mapped, or hashed, to the index
- Hash code
- Hash index
- Collision
    - Open Addressing w/ linear probing
        - Resolves collision during hashing by examining consecutive locations in a hash table.
        - Beginning at original hash index
        - find the next available one
    - Others: Quadratic probing, double hashing
    - Separate chaining

# Trees

- Binary Tree
- General Tree
    - Check syntax of a string for valid algebraic expression
    - if valid can be expressed as a parse tree
    - parse tree must be a general tree
    - compilers use parse trees to check syntax and produce code
- Expression & Decision Trees

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled.png)

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%201.png)

- BST and Heaps
    - Binary Search tree:
        - Node’s data greater than all data in node’s left subtree
        - Node’s data is less than all data in the right subtree
        
        ![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%202.png)
        

 

## Drawing Trees based off of In order and post order

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%203.png)

# Implementations

- Binary Node
- BST
- Heaps

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%204.png)

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%205.png)