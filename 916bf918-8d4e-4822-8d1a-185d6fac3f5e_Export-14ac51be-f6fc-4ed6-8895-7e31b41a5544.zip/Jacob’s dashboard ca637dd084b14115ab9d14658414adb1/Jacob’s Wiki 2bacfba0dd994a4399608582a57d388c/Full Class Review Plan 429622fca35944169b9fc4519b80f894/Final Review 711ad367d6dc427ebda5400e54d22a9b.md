# Final Review

4 quizzes + 1 implementation

```
10-15 mc/fill in the blank
Graph - topoligical, breathfirst/depthfirst traversal, shortest path, cheapestpath
-- Topological: Keep visiting until there are no more neightbors then put on stack 
-- Breathfirst: Visit neighbors and add them to queue, then keep going 
-- Depthfirst: Keep visiting until there are no neighbors and then add them 

pseudo code for an algorithm, Interface and implementation question - free to use any method
```

An **Abstract Data Type (ADT)** in computer science is a type (or class) for objects whose behavior is defined by a set of values and operations. The "abstract" notion refers to the fact that it provides a way to **separate the interface of a data structure from its implementation**. It’s basically a high-level description of data collection and the operations that can be performed on that data. It's "abstract" because it gives an implementation-independent view; the data type user need not know how the data type is implemented. For instance, think of an ADT as a blueprint and an object as an instance of a class created from that blueprint. The ADT defines the behavior of the object’s operations (like a stack ADT might define push and pop operations), but it does not define how these operations are implemented (that is, how the data is stored in memory).

This separation is useful because:

- It simplifies the process of designing complex systems by breaking them down into smaller, more manageable parts.
- It allows different implementations to be swapped in and out without affecting the rest of the system, providing flexibility and re usability.
- It allows the implementation details to be hidden, reducing complexity and potential errors.

# ******************************Dictionary ADT******************************

- Array-Based
    - You can store key-value pairs in parallel arrays and encapsulated in an object
- Singly-linked list

## ****************************Implementations****************************

- Array-based
- Linked list

Write a Java statement to create an instance of class ***********Dictionary*********** that implements ***********DictionaryInterface.*********** Your dictionary contains *****Word***** objects that are a list of synonyms for words. The key value is a *******String******* representing the word to look up. Call your dictionary **********thesaurus**********.

```
DictionaryInterface<String,Word> thesaurus = new Dictionary<>();
```

# ****************Hashing****************

Hashing is a good technique for implementing a dictionary when ********************searching******************** is the primary task. 

The **Two functions of hashing:** 

1.  Convert search key to an integer called the hash code.
2.  Compress hash code into the range of indices for hash table, which is an array.
- Hash code
- hash index
- Collisions
    - Open addressing w/ linear probing
        - The method of resolving a collision in a hash table by examining consecutive locations to find the next available one, starting at the original hash index
        - We must consider how to encode occupied positions, empty positions, and available positions
    - others: quadratic probing, double hashing
    - separate chaining
        - Resolving collisions using buckets

# Trees

- Binary Tree
- General Tree
    - Check syntax of a string for valid algebraic expression
    - if valid can be expressed as a parse tree
    - parse tree must be a general tree
    - compilers use parse trees to check syntax and produce code
- Expression & Decision Trees

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled.png)

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%201.png)

- BST and Heaps
    - Binary Search tree:
        - Node’s data greater than all data in node’s left subtree
        - Node’s data is less than all data in the right subtree
        
        ![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%202.png)
        

 

## Drawing Trees based off of In order and post order

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%203.png)

## Implementation

- Binary Node
- BST
    - ******************************What will the the inorder traversal of a BST of country names show?******************************
        - Alphabetical list of thse country names
- Heaps
    - ********************************************************************************The two applications that make use of the max heap:********************************************************************************
        - Priority queue and heap sort

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%204.png)

![Untitled](Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3/Untitled%205.png)

![Untitled](Final%20Review%20711ad367d6dc427ebda5400e54d22a9b/Untitled.png)

## Bag

```java
class ArrayBag<T> implements BagInterface<T>{
    
    // Creates the ArrayBag object.
    private final T[]  arrayBag;

    // Creates a counter for the number of entries. 
    private int numEntries;

    // Sets the max to 25 tp ensure maximum. 
    private static final int DEFAULT_CAPACITY = 25;

    // default constructor, will default to 25.
    public ArrayBag()
    {
        this(DEFAULT_CAPACITY);
    }

    // constructor with specified size. 
    public ArrayBag(int desiredCapacity)
    {
        
        @SuppressWarnings("unchecked")
        // create the bag array
        T[] tempBag = (T[])new Object[desiredCapacity];
        numEntries = 0;
        arrayBag = tempBag;
        
    }

    // return the current size of the bag
    public int getCurrentSize()
    {
        return numEntries;
    }

    // true if bag is empty otherwise false
    public boolean isEmpty()
    {
        return numEntries == 0;
    }

    // adds an entry to the bag
    public boolean add(T newEntry)
    {
        
        // if the bag is full, do not add stuff to it and return false.  
        if (arrayBag.length == numEntries)
        {
            return false;
        }

        // insert at the last using the numEntries index. 
        arrayBag[numEntries] = newEntry;

        // increment numEntries and return true since an item was successfully added. 
        numEntries++;
        return true;
    }

    public T remove()
    {
        // if arrayBag is not empty remove the last element and subtract one from the numEntries.
        
        if(! this.isEmpty())
        {
            int lastIndex = --numEntries;
            return arrayBag[lastIndex];
        }
        
        return null;
    }

    public boolean remove(T searchEntry)
    {
        // loop through the bag and check for anEntry.
        
        for(int i=0; i < this.getCurrentSize() ; i++)
        {
            
            // if the value exist in the bag
            if(arrayBag[i].equals(searchEntry))
            {
                
                // shift all the right side values one times toward left
                for(int j=i;j<arrayBag.length - 1;j++)
                {
                    arrayBag[j] = arrayBag[j+1];
                }
                    
                // decrement the numEntries
                numEntries--;
                
                return true;
            }
        }
        return false;
    }

    public void clear()
    {
        // make numEntries 0
        numEntries = 0;
    }

    public int getFrequencyOf(T searchEntry)
    {
        int frequency = 0;
        
        // count the frequency of the given object
        for(int i=0; i<arrayBag.length; i++)
        {
            if(arrayBag[i].equals(searchEntry))
            {
                frequency++;
            }

        }
        
        // returns the frequency
       return frequency;
    }

    public boolean contains(T searchEntry)
    {
        // checks for the entry in the arrayBag
        for(int i=0; i<arrayBag.length; i++)
        {
            if(arrayBag[i].equals(searchEntry))
            {
                return true;
            }
        }
        return false;
    }

    public T[] toArray(){
        // returns a copy of the arrayBag array
        return arrayBag.clone();
    }
}
```

```java
public interface BagInterface<T> {
    
    /** Gets the current number of entries in this bag.
    @return The integer number of entries currently in the bag. */
    
    public int getCurrentSize();

    /** Sees whether this bag is empty.
    @return True if the bag is empty, or false if not. */
    
    public boolean isEmpty();

    /** Adds a new entry to this bag.
    @paramnewEntry The object to be added as a new entry.
    @return True if the addition is successful, or false if not. */
    
    public boolean add(T newEntry);
    
    /** Removes one unspecified entry from this bag, if possible.
    @return Either the removed entry, if the removal.
    was successful, or null. */
    
    public T remove();

    /** Removes one occurrence of a given entry from this bag, if possible.
    @paramanEntry The entry to be removed.
    @return True if the removal was successful, or false if not. */
    public boolean remove(T anEntry);
    
    /** Removes all entries from this bag. */
    public void clear();

    /** Counts the number of times a given entry appears in this bag.
    @paramanEntry The entry to be counted.
    @return The number of times anEntryappears in the bag. */
    
    public int getFrequencyOf(T anEntry);

    /** Tests whether this bag contains a given entry.
    @paramanEntry The entry to find.
    @return True if the bag contains anEntry, or false if not. */
    
    public boolean contains(T anEntry);
    
    /** Retrieves all entries that are in this bag.
    @return A newly allocated array of all the entries in the bag.
    Note: If the bag is empty, the returned array is empty. */
    
    public T[] toArray();
}  
// end BagInterface
```

## Stack

```java
import java.util.EmptyStackException;

public final class LinkedStack<T> implements StackInterface<T> {
    private Node topNode; // Gets the top node in the chain.

    public LinkedStack() {
        topNode = null;
    }

    @Override
    public void push(T newEntry) {
        Node newNode = new Node(newEntry, topNode);
        topNode = newNode;
    }

    @Override
    public T pop() {
        T top = peek();
        // Assertion: topNode != null
        topNode = topNode.getNextNode();
        return top;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        } else {
            return topNode.getData();
        }
    }

    @Override
    public boolean isEmpty() {
        return topNode == null;
    }

    @Override
    public void clear() {
        topNode = null;
    }

    private class Node {

        private T data;
        private Node next;

        private Node(T dataPortion) {
            this(dataPortion, null);
        }

        public LinkedStack<T>.Node getNextNode() {
            return this.next;
        }

        public T getData() {
            return this.data;
        }

        private Node(T dataPortion, Node nextNode) {
            data = dataPortion;
            next = nextNode;
        }

    }

}
```

```java
public interface StackInterface<T> {
    /** Adds a new entry to the top of the stack. */
    /** @param newEntry An object that will be added to the stack. */
    public void push(T newEntry);

    /** Removes and returns this stack's top entry. */
    /** @return The object at the top of the stack. */
    /** @throws EmptyStackException if the stack is empty before the operation. */
    public T pop();

    /** Retrieves this stack's top entry. */
    /** @return the object at the top of the stack */
    /** @throws EmptyStackException if the stack is empty */
    public T peek();

    /** Detects whether this stack is empty */
    /** @return True if the stack is empty */
    public boolean isEmpty();

    /** Removes all entries from this stack */
    public void clear();
}
```

## Queue, Dequeue, and PQ

```java
public class Queue<T> implements QueueInterface<T> {

    // The node at the front of the queue
    private Node firstNode;
    // The node at the end of the queue
    private Node lastNode;
    // The current size of the queue
    private int size;
    
    // Constructor that initializes the queue to be empty
    public Queue() {
        firstNode = null;
        lastNode = null;
        size = 0;
    }
    
    // Method to add a new entry at the end of the queue
    public void enqueue(T newEntry) {
        Node newNode = new Node(newEntry, null);
        if (isEmpty()) {
            firstNode = newNode;  // If queue is empty, the new node becomes the first node
        }
        else {
            lastNode.setNextNode(newNode);  // Otherwise, link the new node after the current last node
        }
        lastNode = newNode;  // The new node becomes the last node
        size++;  // Increase the size of the queue
    }
    
    // Method to remove and return the entry at the front of the queue
    public T dequeue() {
        T front = null;
        if (!isEmpty()) {
            front = firstNode.getData();  // Retrieve data from the first node
            firstNode = firstNode.getNextNode();  // Remove the first node by making the second node the new first node
            size--;  // Decrease the size of the queue
            if (isEmpty()) {
                lastNode = null;  // If queue becomes empty, update the last node to be null
            }
        }
        return front;
    }
    
    // Method to retrieve the entry at the front of the queue without removing it
    public T getFront() {
        T front = null;
        if (!isEmpty()) {
            front = firstNode.getData();  // Retrieve data from the first node
        }
        return front;
    }
    
    // Method to check if the queue is empty
    public boolean isEmpty() {
        return firstNode == null;
    }
    
    // Method to clear the queue
    public void clear() {
        firstNode = null;
        lastNode = null;
        size = 0;
    }
    
    // Method to get the current size of the queue
    public int size() {
        return size;
    }
    
    // This is a private inner class for a node in the queue.
    private class Node {
        // The data stored in this node
        private T data;
        // The node after this one in the queue
        private Node next;
        
        // Constructor that initializes the node with a given data and sets the next node to be null
        private Node(T dataPortion) {
            this(dataPortion, null);
        }
        
        // Constructor that initializes the node with a given data and a given next node
        private Node(T dataPortion, Node nextNode) {
            data = dataPortion;
            next = nextNode;
        }
        
        // Method to get the data stored in this node
        private T getData() {
            return data;
        }
        
        // Method to set the data stored in this node
        private void setData(T newData) {
            data = newData;
        }
        
        // Method to get the next node after this one
        private Node getNextNode() {
            return next;
        }
        
        // Method to set the next node after this one
        private void setNextNode(Node nextNode) {
            next = nextNode;
        }
    }
}
```

```java
public interface QueueInterface<T> {
    /**
     * Adds a new entry to the back of this queue.
     * 
     * @param newEntry An object to be added.
     */
    public void enqueue(T newEntry);

    /**
     * Removes and returns the entry at the front of this queue.
     * 
     * @return The object at the front of the queue.
     * @throws EmptyQueueException if the queue is empty before the operation.
     */
    public T dequeue();

    /**
     * Retrieves the entry at the front of this queue.
     * 
     * @return The object at the front of the queue.
     * @throws EmptyQueueException if the queue is empty.
     */
    public T getFront();

    /**
     * Detects whether this queue is empty.
     * 
     * @return True if the queue is empty, or false otherwise.
     */
    public boolean isEmpty();

    /** Removes all entries from this queue. */
    public void clear();
}
```

```java
/**
 * An interface for the ADT priority queue.
 */
public interface PriorityQueueInterface<T extends Comparable<? super T>> {
	/**
	 * Adds a new entry to this priority queue.
	 * 
	 * @param newEntry An object to be added.
	 */
	public void add(T newEntry);

	/**
	 * Removes and returns the entry having the highest priority.
	 * 
	 * @return Either the object having the highest priority or, if the
	 *         priority queue is empty before the operation, null.
	 */
	public T remove();

	/**
	 * Retrieves the entry having the highest priority.
	 * 
	 * @return Either the object having the highest priority or, if the
	 *         priority queue is empty, null.
	 */
	public T peek();

	/**
	 * Detects whether this priority queue is empty.
	 * 
	 * @return True if the priority queue is empty, or false otherwise.
	 */
	public boolean isEmpty();

	/**
	 * Gets the size of this priority queue.
	 * 
	 * @return The number of entries currently in the priority queue.
	 */
	public int getSize();

	/** Removes all entries from this priority queue. */
	public void clear();
} // end PriorityQueueInterface
```

```java

```