# Internship Journal

Author : @Jacob Jayme

# Overview

Here I will write daily about what happened at my internship and what I can do to improve on it. Thinking of doing this on written paper just so I can sort of evaluate what I did good that day and what I can improve on as well as the progress that I will have through out. 

# Initial Meeting

Initial meeting with Renee and Connie told me that this was very new to them. Renee is my hiring manager and Connie is my mentor. Both have very extensive compliance experience but, I think Renee is more on the technical side and Connie is more compliance oriented. The gist of what I got is that they want me to hard focus on a project, something that I can call my own at the end of the internship and have on my resume. Renee hinted more at a return but, Connie is not really sure about it since she has only seen one person ever get a return at Meraki (Omar). Might have to ask Jeet to introduce him to me. Here are the raw notes for the initial project, I will probably rewrite this as I get more details. 

```
Trying to put together a proof of concept for automating the testing of some of these compliance controls. Going over frameworks and get a feel over controls and stuff. Might go about it a little differently. GRC Tool called Highbond, and the company is called galvanized. 

Week 1: Training, get your computer setup, use webex for meetings

Controls, GRC Tools orientation, strategy, then we take a look at the controls and what we think and put a proof of concept on. GRC tools bassed on assesment.  

Setup meetings with SME about documentation as a service, what kind of tools do we need? Gitlab? Where is the best place to put this information

Process: 
Identify the control 
Log the tool that has implemented that control 
- help engineers understand implementing controls, controls implemented by engineers okta and ldap that have access to teams, IT uses okta to do auth, baseline configuration on there as well
identify the location of the document
determine if highbond can support that, if not use another tool
have a dashboard mockup, can highbond do it? 
then a presentation, be at all of them

** Test at implementation point to make sure its compliant 
** Narrative of control implemented

these controls are tested by this and implemented by that

Romeilly Lundon 

Can we create scripts that live within the infrastructure and run tests and bring back the results 

There is a strategy document, big value in this is will mitigate the time engineers have to spend anything to do with compliance
Less interaction with Engineering and they'll have what they need 

Documentation as a service will be put into highbond, scripting for pulling that out will be something work with it
```

In summary though, the big idea is: **************************************************************************************************************************************************************Mitigate the time engineers have to spend anything to do with compliance so they can focus on more important tasks.************************************************************************************************************************************************************** It looks like my main job will just be development of this tools since I’m the only one that knows how to code, and use pipelines such as git lab and such. (Need to look at git lab). I do have three days to start honing my skills and sharpening them until I get into, so I need to set aside projects for that. I’ve had experience with pytest and such but I think right now I really only have solid experience with APIs so I have to find some pytest test automation scripts to test things like controls or other things like AWS vulnerabilities. 

Some additional notes from Luis:  

- get a spread sheet of the tools available to you as well as your access level in them(things like api access, what calls can you make etc etc) will make life easier when you start building
- if you are sharing info with another dept it’s gonna come down to really (how ez can I make this for them) ensure you know their tools and what you can provide over to them
- start simple. Get a only 1 or 2 controls automated to start with and make sure they consistently work. From there build out

# Projects

So I want to start doing more project oriented stuff on top of my homework and social life at SF. I think I’ll have a competitive edge regardless of what I do, and I just gain more experience while I’m at it. Might also revive my website, it depends on how quickly I accomplish the projects. 

## Notion Project Management Implementation with Discord

This project is really cool because, it will benefit SWIFT as well. I need to start making a notion or just a README on how the program works, and cleaning up the code but, it works pretty well right now. This is more of me parsing information and displaying it on discord for people to see. Having a flow chart will be good as well. I could possibly finish it the night I get to SF just to get it done with and get that extra experience with commits and such. Remind me to make a notion page for this. Simple enough I don’t need a blog to guide me. 

## TerraGoat

Also look at this, does not include modules for things like pytest but trains me in identifying vulnerabilities and fixing them. Uses a scanner as well, can also use that scanner then output the results on a site. Also has controls and compliance things I can take a look at. 

[Introducing TerraGoat, a “vulnerable-by-design” Terraform training project - Bridgecrew Blog](https://bridgecrew.io/blog/terragoat-open-source-infrastructure-code-security-training-project-terraform/)

## Automated Cloud Infrastructure Testing tool with with Terraform and PyTest

This one is really cool since I’ll get more experience with terraform and such. Really interesting project, and for my own spin on it, put the results of pytest on to a dashboard and output the results. 

[Creating an Automated Cloud Infrastructure Testing Tool with Terraform and PyTest](https://www.fugue.co/blog/blog-post-creating-an-automated-cloud-infrastructure-testing-tool-with-terraform-and-pytest)

Also create a write up of this and how it works. 

Yeah so for these projects I’ll just focus on these two so I properly document them and know everything about them before my start date on Tuesday. If I can’t get these done before my start date, I think taking the time to do them the first week of my internship will be fine. Ideally I would like to do one a day but I should take my time and consume the information that is given to me. 

## Day 1 - 5/30/2022

Today was pretty much on-boarding, I got to meet everyone on different teams. Did not really talk to the other security interns as much, other people didn’t really seem like they wanted to talk to me but I also might be overthinking. Got my mac that was cool, saw a lot of food there. Wrote down who I wanted to meet on the compliance team and decided I would rotate who I would talk to every week, and sort of see what kind of projects I could get on. Not much really happened, just getting situated.