# Sapphire NITRO+ Radeon RX 6700 XT 12 GB Video Card

Price: 439.99
Site: Amazon