# AMD Ryzen 5 7600X 4.7 GHz 6-Core Processor

Price: 299
Site: Newegg