# ROG Strix X670E-I Gaming WiFi

Price: 469.99
Site: Newegg