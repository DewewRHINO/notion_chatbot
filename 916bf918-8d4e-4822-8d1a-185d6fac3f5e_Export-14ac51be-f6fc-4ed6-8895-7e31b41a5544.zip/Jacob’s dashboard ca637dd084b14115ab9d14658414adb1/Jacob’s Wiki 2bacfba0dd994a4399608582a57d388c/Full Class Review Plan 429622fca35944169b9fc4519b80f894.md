# Full Class Review Plan

Author : Jacob Jayme

Academic Plan to make sure I don’t fail my classes. This is focused to the point where I focus on passing my Asynchronous classes as well as my CS 2400 and STA 2260 class. I’m in the danger zone for CS 2400 because, I failed the midterm but, these are the grades that I need for each class. Everyday I should be putting in at least an hour and a half in each class. Over Spring break will be review on the things that I have gone over. 

# Scheduling and Organization

Every morning spend at least 30 minutes looking over your schedule for the week. This includes assignments due that week as well as scheduling preparations for exams and status of each. Also check the class discord to see if there is anything that was missed. 

# CS 2400

First midterm was a 22/50 which is a 44% puts me in a really bad spot. I need to talk to Thanh N. to see if there is anything I can do to help remediate that. 

![Untitled](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/Untitled.png)

[Midterm 2 Review](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/Midterm%202%20Review%20d64c1eb33eb3439fad6b9dc24eae73d3.md)

[Final Review](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/Final%20Review%20711ad367d6dc427ebda5400e54d22a9b.md)

[](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/Untitled%2098a28ab746da40d1977ca39263a1b2ff.md)

# CS 2640

Still waiting for results on the projects and midterm. Will depend on that if I have to worry about it. I need to start going to class here. 

![Untitled](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/Untitled%201.png)

[CS2640 Final Study Guide](Full%20Class%20Review%20Plan%20429622fca35944169b9fc4519b80f894/CS2640%20Final%20Study%20Guide%200ee0281eeaf3414e9d3ddf7588f8e464.md)

# STA 2260

Failed the first quiz. Next quiz most likely after Spring break. Missed the quiz after Spring Break, now trying to recover the semester. I want to say homework grade will be around 70%, not entirely sure but, this semester will be based off the quiz and the final exam. 

## Quiz #3 Plan

Read over Chapter 7 notes then redo questions in notes. Make sure everything is filled out and understood. Talk to yourself through what the chapter is about and the problem it entails. Make sure you can do the problems on the notes by yourself. Do the same thing for Chapter 8. After look at homework and attempt to do the questions yourself, and keep doing them until you can, then look at practice quiz before Tuesday. 

## Final Plan

Fucking cry