# ChatGPT Projects

[https://www.youtube.com/watch?v=uRQH2CFvedY](https://www.youtube.com/watch?v=uRQH2CFvedY)