# Home Lab Overview

Made by the illustrious Evan Deters. 

# OS Requirements

- [ ]  Pokemon Center DC - Windows Server 2022 (Domain Controller)
- [ ]  Pokemon Center Web Server - Windows Server 2016 (XAMPP Web Server)
- [ ]  Pokemon Center Backup Server - Windows Server 2012 R2 (IIS Web Server, Secondary Domain Controller)
- [ ]  Nurse Joy’s Desktop - Windows 10 (Client)
- [ ]  Nurse Joy’s old computer - Windows 7 (SMB)
- [ ]  PC Box Database - Ubuntu 22.04 (MySQL)
- [ ]  PC Box Front End - CentOS 7 (Apache Web Server)
- [ ]  PC Box Proxy - Debian 11 (Nginx Web Proxy)
- [ ]  Nurse Joy’s file storage - Ubuntu 18 (SFTP)

# Service Requirements

1. Active Directory
    1. Primary Domain Controller and Primary DNS Server → Windows Server 2022
    2. Secondary DC and DNS → Windows Server 2016
    3. All machines should be joined to the Domain
2. XAMPP Web Server
    1. WordPress Website using Ubuntu 22.04 for Database
3. SMB
    1. Windows 7 shares proprietary SWIFT data (🍆) to only Windows 10 Client
4. MySQL
    1. Database for Windows Server 2016 and CentOS 7
    2. **Ensure database is secure from Justin’s hands.**
5. Apache Web Server
    1. WordPress Website using Ubuntu 22.04 for Database
6. Nginx Web Proxy
    1. Proxy for IIS Website
7. SFTP
    1. Share classified SWIFT HR data (🍑) to only Windows 10 Client

# Security Considerations

- SWIFT shouldn’t be leaking our proprietary data to other clubs. That is how insurrections occur.
- SWIFT does not want violations of GDPR, as we operate worldwide. Make sure that HR data is locked down.
- The IIS Web Server shouldn’t be reachable from any of its computer’s interfaces. That’s what the Web Proxy is for!
- NSA released a different beast in 2017, however you are running the same animal. Please tame it.
- WordPress creds 🤔
- We don’t accept credit cards, but we still want to be 1/12th PCI-DSS compliant. Please follow PCI-DSS requirement 1 for all machines.

# Tools

1. Zeek:

[https://zeek.org/](https://zeek.org/)

Network Security Monitoring

2. ClamAV:

[https://www.clamav.net/](https://www.clamav.net/)

Antivirus

3. OpenVAS:

[https://www.openvas.org/](https://www.openvas.org/)

Vulnerability Scanner

4. TheHive:

[https://lnkd.in/e7aVCRUZ](https://lnkd.in/e7aVCRUZ)

Incident Response

5. PFSense:

[https://www.pfsense.org/](https://www.pfsense.org/)

Security appliance (firewall/VPN/router)

6. Elastic:

[https://www.elastic.co/de/](https://www.elastic.co/de/)

Analytics

7. Osquery:

[https://www.osquery.io/](https://www.osquery.io/)

Endpoint visibility

8. Arkime:

[https://arkime.com/](https://arkime.com/)

Packet capture and search

9. Wazuh:

[https://wazuh.com/](https://wazuh.com/)

XDR and SIEM

10. Alien Vault Ossim:

[https://lnkd.in/eShQt29h](https://lnkd.in/eShQt29h)

SIEM

11. Velociraptor:

[https://lnkd.in/eYehEaNa](https://lnkd.in/eYehEaNa)

Forensic and IR

12. MISP project:

[https://lnkd.in/emaSrT57](https://lnkd.in/emaSrT57)

Information sharing and Threat Intelligence

13. Kali:

[https://www.kali.org/](https://www.kali.org/)

Security OS

14. Parrot:

[https://www.parrotsec.org/](https://www.parrotsec.org/)

Security OS

15. OpenIAM:

[https://www.openiam.com/](https://www.openiam.com/)

IAM

16. Yara:

[https://lnkd.in/eEJegEak](https://lnkd.in/eEJegEak)

Patterns

17. Wireguard:

[https://www.wireguard.com/](https://www.wireguard.com/)

VPN

18. OSSEC:

[https://www.ossec.net/](https://www.ossec.net/)

HIDS

19. Suricata:

[https://suricata.io/](https://suricata.io/)

IDS/IPS

20. Shuffler:

[https://shuffler.io/](https://shuffler.io/)

SOAR

21. Phish Report:

[https://phish.report/](https://phish.report/)

Anti Phishing

22. Graylog:

[https://lnkd.in/eAFuUmuw](https://lnkd.in/eAFuUmuw)

Logmanagement

23. Trivy:

[https://lnkd.in/e7JxXStY](https://lnkd.in/e7JxXStY)

DevOps/IaC Scanning

24. OpenEDR:

[https://openedr.com/](https://openedr.com/)

EDR

25. Metasploit:

[https://lnkd.in/e4ECX-py](https://lnkd.in/e4ECX-py)

Pentest

26. NMAP:

[https://nmap.org/](https://nmap.org/)

Old but gold