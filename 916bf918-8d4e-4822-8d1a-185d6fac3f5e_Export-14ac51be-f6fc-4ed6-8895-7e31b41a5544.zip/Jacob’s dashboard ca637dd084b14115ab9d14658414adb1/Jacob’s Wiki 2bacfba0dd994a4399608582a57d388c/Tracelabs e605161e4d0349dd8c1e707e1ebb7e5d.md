# Tracelabs

[Resources](Tracelabs%20e605161e4d0349dd8c1e707e1ebb7e5d/Resources%20097588b553664e73ba808f09f5fd72bf.md)

**************OSINT:************** Open Source Intelligence refers to the collection, processing and analysis of publicly available data that has been determined to be of intelligence value. Sources include surface, deep and dark web, social media, news media, academic sources, and government records. 

#OSINTForgood = Using OSINT skillsets to further a charitable or ethical cause.

**********************************Trace Labs Model**********************************

- Use crowdsourced OSINT to help with missing persons cases that law enforcement has requested the public’s assistance with
- Bring together hundreds of skilled investigator through CTF events and ongoing operations to crowdsources new leads on cases using only OSINT
- Crowdsource the collection of OSINT and crowdsource the processing

## Core Functions

- ************************************************Missing Person Awareness************************************************
- ************************************************************OSINT Search Party CTF Events************************************************************
- ************Ongoing Operations************
- ******************Training******************

## Key Rules of Engagement our Community Follows

- **Zero Touch Recon -** Contacting a missing subject, the family of the missing subject, or friends of the missing subject is not permitted
- **Relevant Intel Sources -** No speculative sources
- **Show Your Work -** All intel submitted must have a publicly verifiable link along with it and a description of it’s relevance