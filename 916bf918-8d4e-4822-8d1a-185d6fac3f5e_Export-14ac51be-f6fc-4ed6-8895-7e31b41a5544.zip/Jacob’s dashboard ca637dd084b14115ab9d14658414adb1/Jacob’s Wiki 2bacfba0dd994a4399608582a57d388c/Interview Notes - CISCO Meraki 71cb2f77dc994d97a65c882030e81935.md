# Interview Notes - CISCO Meraki

# Self Introduction:

- Second year Computer Science student at CPP with an emphasis in cybersecurity
- SWIFT Co-Director of Membership
    - Used to be on both competition teams with an emphasis on perimeter defense and business injects. Mainly host workshops on networking and cloud concepts. Networking lead for our Collegiate Cyber Defense Competition and Alternate for our Collegiate penetration testing competition.
- Cyber tools and Engineering at So Cal Edison
    - Member of the Cloud Security Engineering team and NDR team. Cloud security mainly focus on Netskope work where I’m tasked with Environment creation, automation, and testing in Azure and on premise as well as documentation of work performed. NDR work with Corelight appliances and keep them updated and secure.
- Co-Director for the Student Run Data center
    - vSphere and advertising resources for students to use as well as helping out with the development of workshops clubs would like to host. For example if someone wanted to host a VPN workshop or host VMs for students to use in class my role would be to support them.

# Why do you want to join our company? What are you looking to gain from working with us?

- Definitely the main reason why I want to join Cisco Meraki is because, of the community. I truly believe in what a community can do for a person and how much they can thrive just being around passionate and hard working mentors. I’m looking to gain that environment so that I can also thrive in it and learn from amazing and passionate people and also develop the ability to foster even more growth in the future.

# Why are you interested in Cybersecurity?

- Problem solving

# What is your greatest Achievement?

- SWIFT Pals

# Why do you want to do compliance?

- ITC
- Home lab

# Things I did in my life

- 2 years of Cyberpatriot in HS
- Cisco Networking Instructor at Troy High School, taught 6 hours a week teaching Cisco Networking
- K12 Cybertalk
- Teaching Girlscouts cybersecurity
- SWIntern + SWIFT Co-director of membership
    - SWIFT Pals
    - SWIntern recruiter
    - Taught and led 6 workshops (OSINT, Cloud, 2 Networking workshops, cloud workshop, and IR workshop)
    - ISACA representative
    - Alumni outreach team
    - Tech Symposium Team
    - Ops team
- Fragfest Network lead
- CCDC Networking Lead + CPTC Alt
    - Taught at cyber bootcamps
- Cybertools and Engineering Intern at SCE
- Co-director at the Mitchell Data Center

# Technical Interview prep

**Work closely with the Compliance Architect to design and implement automation tools for monitoring and reporting on compliance with industry standards.**

- Talk about how you helped maintain and use a scoring engine for RvB detecting if services were up or not.
- Talk about your job at the SDC and how they have audits making sure everything is compliant and secure.

**Knowledge of security and compliance standards, including SOC 2, PCI DSS, FedRamp/NIST, and others.**

- SOC 2:
    - Based on security, availability, processing integrity, confidentiality, and privacy.
    - How to manage customer data
    - Type 1: Describes the organization’s systems and whether the system design complies with the relevant trust principles
    - Type 2: details the operational efficiency of these systems.

**Gain hands-on experience with Python programming and scripting.**

- Scoring Engine
- CS student, learning Abstract data structures right now
- Created a power shell script on Azure devops to automate netskope agents

**Participate in cross-functional team meetings to discuss compliance processes and procedures.**

- Part of the security team and NDR team at socal edison
- Usual scribe for the post mortems at edison

**Contribute to the development of comprehensive documentation of all compliance monitoring processes.**

- Created Netskope Wiki for Edison
- Created documentation for Student Data Center

Aside from the infrastructure that I help with at SWIFT, my workload recently has been being a part of two executive boards, working two part-time jobs, and taking seven classes. Apart from standing up IT infrastructure for Cybersecurity clubs, I also helped co-create a mentorship program called SWIFT Pals and helped create an intern program at SWIFT called SWInterns. SWIFT Pals was designed to bridge the gap between general members and the executive board. When SWIFT starts workshops, general members only get a little out of it, only the people teaching the seminars because they are the ones that do the workshop and prepare them. SWIFT Pals creates groups of four people with two mentors with extensive experience in Cybersecurity or specialization, such as Pentesting or IT Infrastructure. This is great because it builds relationships between general and board members, making general members more involved and more likely to try new things if they know someone. I spend the first two weeks of school for around eight-twelve hours each week interviewing each person making sure I pair them up with the right mentor because mentors are vital to success. Especially for SWIFT, the club is definitely peer-mentor oriented, and I would only be where I am with it. I had a Cybersecurity Engineering Internship during my first year because I talked about my experiences and trial by fire in the club and how I adapted to every situation with my club that was thrown at us. I kept contributing, and now Cisco Meraki has offered to fly me out to San Francisco for the summer with a six-figure salary before I even have a degree. It's all because of the people I was so lucky to meet when I first came here. Now I want to create that environment for other people and make it more accessible through this pals program, in that it fosters growth and instills the passion for Cybersecurity that my mentors instilled in me when I came in; I just want to give back and help people be successful.