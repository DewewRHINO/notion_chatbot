# Windows Server 2022

Status: In Progress
Assign: Vincent Pastrami
Due: December 30, 2022

- Learn Powershell
    - Get List of AD Users
    - Get List of GPOs
    - Create Users based on CSV
    - Create Script to change firewall
- Get familiar with AD
    - Test out different Group Policies