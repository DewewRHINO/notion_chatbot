# CentOS 7

Status: In Progress
Assign: Jacob Jayme
Due: December 30, 2022

[How to Install WordPress with LAMP Stack on CentOS 7](https://www.letscloud.io/community/how-to-install-wordpress-on-centos-7)

# LAMP Stack Configuration

---

### 1. Install Apache

```bash
yum install httpd
systemctl start httpd.service

# Starts it on boot 
systemctl enable httpd.service
```

### 2. Install MySQL (MariaDB)

```bash
yum install mariadb-server mariadb
systemctl start mariadb
mysql_secure_installation

# Starts it on boot 
systemctl enable mariadb.service
```

### 3. Install PHP

```bash
yum install php php-mysql
systemctl restart httpd.service
```

### 4. Verify installation

Visit `Visit [http://your_server_IP_address/info.php](http://your_server_IP_address/info.php)` 

### 5. Download WordPress

1. Go to `cd /var/www/html`
2. Download WordPress: `wget https://wordpress.org/latest.tar.gz`
3. Extract: `tar xvzf latest.tar.gz`
4. Move WordPress contents to your web directory: `mv /var/www/html/wordpress/* /var/www/html`

### 6. Create a mySQL Database

1. `mysql -u root -p`
    1. `CREATE DATABASE wordpress;`
    2. `GRANT ALL PRIVILEGES on wordpress.* to 'wordpress_user'@'localhost' identified by 'wordpress_pw';`
    3. `FLUSH PRIVILEGES;`
    4. `exit`
    5. `nano wp-config.php`

### 7. Install PHP 7

1. `yum install epel-release yum-utils -y`
2. `yum install http://rpms.remirepo.net/enterprise/remi-release-7.rpm`
3. `yum-config-manager --enable remi-php70`
4. `yum install php php-mysql`
5. `systemctl restart httpd`

### 8. WordPress installation

Sign in and start making posts!