# [Template Card]

Status: Not Started
Assign: Jacob Jayme
Due: December 30, 2022